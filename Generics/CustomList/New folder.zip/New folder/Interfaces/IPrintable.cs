﻿namespace CustomList.Interfaces
{
    public interface IPrintable
    {
        void print();
    }
}