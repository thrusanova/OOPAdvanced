﻿namespace CustomList.Interfaces
{
    public interface ISwapable
    {
         int swap();
    }
}