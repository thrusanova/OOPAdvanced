﻿
namespace Telephones
{
  public  interface ICall
    {
        void Call(string number);
    }
}
